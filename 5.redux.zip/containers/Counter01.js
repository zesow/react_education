// 기존 방식.
import React, { Component } from 'react';
import { Segment, Button, Header } from 'semantic-ui-react';

export default class Counter extends Component{

    constructor(props){
        super(props);
        this.state = {
            count : 0
        }
    }

    onPlusCount = () => {
        this.setState({
            count: this.state.count + 1
        })
    }

    onMinusCount = () => {
        this.setState({
            count: this.state.count - 1
        })
    }

    render(){

        return(
            <Segment>
                <Header as='h1'>{this.state.count}</Header>
                <Button primary onClick= {this.onPlusCount}>Add</Button>
                <Button secondary onClick= {this.onMinusCount}>Minus</Button>
            </Segment>
        )
    }
}
