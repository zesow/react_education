// redux 방식.
import React, { Component } from 'react';
import { Segment, Button, Header } from 'semantic-ui-react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import { plus, minus} from '../actions/index';

class Counter02 extends Component{


    render(){

        return(
            <Segment>
                <Header as='h1'>{this.props.count}</Header>
                <Button primary onClick= {this.props.onPlusCount}>Add</Button>
                <Button secondary onClick= {this.props.onMinusCount}>Minus</Button>
            </Segment>
        )
    }
}


// action의 함수 이름들이 매칭됨.
function mapDispatchToProps(dispatch){
    return bindActionCreators(
        {onPlusCount : plus,
        onMinusCount : minus},
         dispatch);
}

// store의 state를 여기의 props 로 만들어줌.
function mapStateToProps(state){
    return {
        count: state
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Counter02);