import React, { Component } from 'react';
import Counter02 from '../containers/Counter02';

class App extends Component {
  render() {
    return (
      <Counter02 />
    );
  }
}

export default App;
