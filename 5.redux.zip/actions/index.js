export function plus(){
    return {
        type: 'PLUS',

    }
}

export function minus(){
    return {
        type: 'MINUS'
    }
}