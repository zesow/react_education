// action 에 반응해야 함.

export default ( state = 5 , action ) => {
    switch(action.type){
        case 'PLUS' :
            return state + 1;
        case 'MINUS' :
            return state - 1;
        default:
            return state;
    }
}