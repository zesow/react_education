
import { combineReducers, createStore, applyMiddleware, compose } from 'redux';
import { routerReducer } from 'react-router-redux';
import thunk from 'redux-thunk';


import {userReducer,userListReducer} from './reducer/index';

const rootReducer = combineReducers({
  //
  routing: routerReducer,
  
  //add module
  userState : userReducer,
  userListState : userListReducer
});

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const store = createStore(
  rootReducer,
  composeEnhancers(
    applyMiddleware(thunk),
  )
);

const {dispatch} = store;
export default store;
export {dispatch};