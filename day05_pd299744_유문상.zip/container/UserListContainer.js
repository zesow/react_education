import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Container, Button } from 'semantic-ui-react';

import UserTableView from '../view/UserTableView';
import UserInsertView from '../view/UserInsertView';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import userListAction from '../action/userListAction';

@autobind
class UserListContainer extends Component {

  componentDidMount(){
    this.findUserList();
  }

  findUserList(){
    this.props.userListAction.findUsers();
  }

  onClickReload(){
    this.findUserList();
  }

  onRouteUser(id){
    const { history } = this.props;
    history.push(`/user/${id}`);
  }

  render(){

    const { users} = this.props;
    return (
      <Container>
    
        <UserTableView 
          users={users}
          // routeUserBasePath = '/users'
          // onRouteUser = {this.onRouteUser}
        />
          
      </Container>
    )
  }
}

// 파라미터 이름이 뭐든지 상관없다. 리덕스에서 알아서 가져와준다.
const mapStateToProps = ({userListState}) => ({
  users : userListState.users,
})

const mapDispatchToProps = (dispatch) => ({
  userListAction: bindActionCreators(userListAction, dispatch),
})

export default connect(mapStateToProps, mapDispatchToProps)(UserListContainer);