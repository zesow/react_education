import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Container, Button } from 'semantic-ui-react';

import UserTableView from '../view/UserTableView';
import UserInsertView from '../view/UserInsertView';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import userAction from '../action/userAction';

import LineButtons from '../shared/LineButtons';
import userListAction from '../action/userListAction';
import PageHeader from '../shared/PageHeader';

@autobind
class UserEditFormContainer extends Component {

  onSetUserProp(name, value){
    this.props.userAction.setUserProp(name, value);
  }

  registerUser(user){
    console.log(user);
    this.props.userAction.registerUser(user);
    
  }

  onRouteUser(id){
    const { history } = this.props;
    history.push(`/user/${id}`);
  }

  render(){

    const { user } = this.props;
    return ( 
        <UserInsertView 
          user = {user}
          onAddUser = {this.registerUser}
          onSetUserProp = {this.onSetUserProp}
        />
    )
  }
}

// 파라미터 이름이 뭐든지 상관없다. 리덕스에서 알아서 가져와준다.
const mapStateToProps = ({userState}) => ({
  user : userState.user,
})

const mapDispatchToProps = (dispatch) => ({
  userAction: bindActionCreators(userAction, dispatch),
})

export default connect(mapStateToProps, mapDispatchToProps)(UserEditFormContainer);