
// Style --------------------------------------------------

import 'semantic-ui-css/semantic.min.css';


// JS -----------------------------------------------------

import 'babel-polyfill/dist/polyfill.min.js';
