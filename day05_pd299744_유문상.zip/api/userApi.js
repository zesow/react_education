import axios from 'axios';

const basePath = '/user-api';

// then == promise . 비동기 데이터 처리.
// 
function findUserList(){
  return axios.get('/user')
  .then((response) => response.data);
}

function findUser(userId){
  return axios.get(`${basePath}/user/${userId}`)
  .then((response) => response.data);
}

function registerUser(user){
  return axios.post(`${basePath}/user`,user)
  .then((response) => response.data)
}

// modify(id,user)
// remove(id)

export default {
  findUserList,
  findUser,
  registerUser,
}