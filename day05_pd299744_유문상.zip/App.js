
import React, { Component } from 'react';
import { Provider } from 'react-redux';

import store from './store';
import Routes from './Routes';

import UserListContainer from './container/UserListContainer';
import UserEditFormContainer from './container/UserEditFormContainer';
import { Container } from 'semantic-ui-react';

class App extends Component {
  render() {
    return(
      <Container>
        
        <Provider store={store}>
          <Routes/>
        </Provider>

        
      </Container>
    );
  }
}

export default App;
