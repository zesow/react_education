
import React, { Component } from 'react';
import { Container, Header, Divider, Grid, Button, Checkbox , Form } from 'semantic-ui-react';
import autobind from 'autobind-decorator';

const items = [
  'Seller',
  'Bidder'
];

@autobind
class UserInsertView extends Component {

  state = {
    roles: []
  }

  onSetUserRoleProp = (value,checked) => {
    if(checked){
      this.state.roles.push(value);
    }
    else{
      this.state.roles.splice(this.state.roles.indexOf(value),1);
    }

    this.props.onSetUserProp('roles',this.state.roles);
  }

  routeUser(userId){
    const { history } = this.props;
    history.push(`/users/${userId}`) // 문자열 내에서 변수를 쓰고 싶을 때.
  }

  render() {

    const { user, onAddUser, onSetUserProp } = this.props;
    const { onSetUserRoleProp} = this.state;

    return (
      <Container style={{ margin: '2em' }}>

        <Header as='h1' content='User List' />
        <Divider />

        <Form>
          <Form.Group>
            <Form.Input
              label='name'
              // value={user && user.name? user.name : ''}
              // onChange={(e) => onSetUserProp('name',e.target.value)}
              onChange = {(e) => {console.log(e.target.value);}}
            >
            </Form.Input>


            <Checkbox
              label="Seller"
              value="Seller"
              onClick = {(e,data) => {onSetUserRoleProp(data.value,data.checked);}}
            />

            <Checkbox
              label='Bidder'
            />


          </Form.Group>
        </Form>

        
        <Grid>
          <Grid.Row>
            <Grid.Column>
              <Button primary floated="left" onClick={onAddUser}>Save</Button>
              <Button floated="left">Cancel</Button>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </Container>
    )
  }
}

export default UserInsertView;
