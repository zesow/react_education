
import React, { Component } from 'react';
import { Container, Header, Divider, Grid, Button, Table, Icon } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import autobind from 'autobind-decorator';

@autobind
class UserTableView extends Component {

  routeUser(userId){
    const { history } = this.props;
    history.push(`/user/${userId}`) // 문자열 내에서 변수를 쓰고 싶을 때.
  }

  render() {

    const { users, routeUserBasePath, onRouteUser} = this.props;
    
    return (
      <Container style={{ margin: '2em' }}>

        <Grid>
          <Grid.Row>
            <Grid.Column>
              <Button primary floated="right">등록</Button>
              <Button floated="right">새로고침</Button>
            </Grid.Column>
          </Grid.Row>
        </Grid>

        <Table celled>
          <Table.Header>
            <Table.Row textAlign="center">
              <Table.HeaderCell>id</Table.HeaderCell>
              <Table.HeaderCell>이름</Table.HeaderCell>
              <Table.HeaderCell>역할</Table.HeaderCell>
              <Table.HeaderCell>Item</Table.HeaderCell>
              <Table.HeaderCell>Bid</Table.HeaderCell>
            </Table.Row>
          </Table.Header>

          <Table.Body>
            {
              Array.isArray(users) && users.length > 0?
                users.map((user) =>
                  <Table.Row key={user.id}>
                    <Table.Cell>{user.id}</Table.Cell>
                    <Table.Cell>{user.name}</Table.Cell>
                    <Table.Cell>{user.roles}</Table.Cell>
                    
                    {
                      user.roles.map((role) => {
                        return(
                        role === "Seller" ? 
                          <Button>Move</Button>
                        : ''
                        )
                      })
                    }
                    {
                      user.roles.map((role) => {
                        return(
                        role === "Bidder" ? 
                          <Button>Move</Button>
                        : ''
                        )
                      })
                    }
                    {/* <Table.Cell><Button>Move</Button></Table.Cell>
                    <Table.Cell><Button>Move</Button></Table.Cell> */}
                  </Table.Row> 
                )
                :
                <Table.Row>
                  <Table.Cell>등록된 사용자가 없습니다.</Table.Cell>
                </Table.Row>
            }

          </Table.Body>
        </Table>

      </Container>
    )
  }
}

export default UserTableView;
