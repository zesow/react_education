const actionType = {
  SET_USER: 'user.setUser',
  SET_USER_PROP: 'user.setUserProp',
  CLEAR_USER: 'user.clearUser'
}

const initialState = {
  user : {}
}

function reducer(state=initialState,action){
  return {
    user: userReducer(state.user,action)
  }
}

function userReducer(userState,{type,payload}){
  switch(type){
    case actionType.SET_USER:
      return [...payload];
    // case actionType.SET_USER_PROP:
    // case actionType.CLEAR_USER:
    default:
      return userState
  }
}

export default reducer;
export { actionType, reducer };