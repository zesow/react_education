
import React, { Fragment }  from 'react';
import { BrowserRouter, Switch, Redirect, Route } from 'react-router-dom';
import UserList from './container/UserListContainer';
import UserInsert from './container/UserEditFormContainer';

const Routes = () => (
  // 화살표함수 route : 레이아웃 먹이기가 쉽다.
  <BrowserRouter basename="/">
    <Switch>
      <Redirect exact from="/" to="/front/user"/>
      <Route path="/front" component={({match}) =>
        <Fragment>
          <Route exact path={`${match.path}/user`} component={UserInsert} />
          <Route exact path={`${match.path}/user`} component={UserList} />
        </Fragment>
      }/>
    </Switch>
  </BrowserRouter>
);

export default Routes;
