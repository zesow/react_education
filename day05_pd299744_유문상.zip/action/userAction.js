import userApi from '../api/userApi';
import { actionType } from '../reducer/userReducer';

function findUser(id){
  return (dispatch) => userApi.findUser(id)
  .then((user)=> {
    dispatchEvent({
      type: actionType.SET_USER,
      payload: user
    })
  })
}

function clearUser(){
  return dispatch => {
    dispatch({
      type : actionType.CLEAR_USER
    })
  }
}

function setUserProp(name, value){
  return (dispatch) => dispatch(
    {
      type:actionType.SET_USER_PROP,
      payload: {name, value}
    })
}

function registerUser(user){
  return () => userApi.registerUser(user);
}

export default {
  findUser,
  clearUser,
  registerUser
}