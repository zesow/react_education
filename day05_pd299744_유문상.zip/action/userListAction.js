import { actionType } from '../reducer/userListReducer';
import userApi from '../api/userApi';

function findUsers(){
  // 여기서 type payload 바로 주는게 아니라 axios 로 받아온 다음 준다..
  return (dispatch) => userApi.findUserList()
    .then((users) => {
      dispatch({
        type: actionType.SET_USERS,
        payload : users
      });
    });
}

export default {
  findUsers,
};
