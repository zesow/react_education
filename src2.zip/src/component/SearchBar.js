import React, {Component} from 'react';
import { Input } from 'semantic-ui-react';

class SearchBar extends Component {

    // 이벤트 헨들링 필요.
    constructor(props) {
        super(props);

        this.state = {
            name: ''
        }

        
    }

    // state를 바꿔주는 메소드가 필요.
    onInputChange(name){
        this.setState({name});
        this.props.onSearchByName(name);
        // 여기서 바뀐 값을 app에게 줘야됨. 그래야 list에게 전달할 수 있으니까.
    }

    render(){
        return(
            <Input 
                icon={{name:'search', circular: true,link: true}}
                value={this.state.name}
                onChange={event => this.onInputChange(event.target.value)}
            />
        );
    }
}

export default SearchBar;