import React, { Component } from 'react'; // pure : 퍼포먼스 향상.
import { Form, Button } from 'semantic-ui-react';

class NewForm extends Component{

    constructor(props){
        super(props);
        this.state = {
            user: {
                name: '',
                phone: '',
                address: '',
                idx: ''
            },
            selectUser: {
                name: '',
                phone: '',
                address: '',
                idx: ''
            },
        }
    }

    componentWillUpdate(nextProps, nextState){
        if(nextProps.selectedUser !== this.state.selectUser){
            this.setState({
                selectUser: nextProps.selectedUser,
                user:nextProps.selectedUser,
            });
        }
    }

    componentDidUpdate(prevProps, prevState) {
        // 여기서는, editing 값이 바뀔 때 처리 할 로직이 적혀있습니다.
        // 수정을 눌렀을땐, 기존의 값이 input에 나타나고,
        // 수정을 적용할땐, input 의 값들을 부모한테 전달해줍니다.
    
        const { info, onUpdate } = this.props;
        if(!prevState.editing && this.state.editing) {
          // editing 값이 false -> true 로 전환 될 때
          // info 의 값을 state 에 넣어준다
          this.setState({
            name: info.name,
            phone: info.phone
          })
        }
    
        if (prevState.editing && !this.state.editing) {
          // editing 값이 true -> false 로 전환 될 때
          onUpdate(info.id, {
            name: this.state.name,
            phone: this.state.phone
          });
        }
      }
    // componentDidUpdate(prevProps, prevState) { // 이전 props, state에 대한 정보
        
    //     if (prevState.user.idx !== this.props.selectedUser.idx) {
    //         this.setState({
    //             user: {
    //                 name: this.props.selectedUser.name,
    //                 phone: this.props.selectedUser.phone,
    //                 address: this.props.selectedUser.address,
    //                 idx: this.props.selectedUser.idx
    //             }
    //         })
    //     }
    //   }

    onSetUserProp(name,value){
        // set 메서드 여러번 안써도 되게 추가된 문법.
        // name이 자동으로 바뀜.
        this.setState({
            user: {
                ...this.state.user,
                [name] : value,              
            },
        })
    }

    onClear(){
        this.setState({
            user: {
                name: '',
                phone: '',
                address: ''
            }
        })
    }

    render(){

        const {user} = this.state;
        const {onAddUser,selectedUser,onUserUpdate,onUserDelete} = this.props;

        return (
            <Form>
                <Form.Group widths='equal'>
                    <Form.Input 
                        label='Name' 
                        placeholder='Name'
                        // user 가 있을 떄만 user.name  
                        value={user && user.name} 
                        onChange = {(e) => this.onSetUserProp('name',e.target.value)} />
                </Form.Group>

                <Form.Group widths='equal'>
                    <Form.Input 
                        label='Phone' 
                        placeholder='Phone'
                        // user 가 있을 떄만 user.name  
                        value={user && user.phone}
                        onChange = {(e) => this.onSetUserProp('phone',e.target.value)} />
                </Form.Group>

                <Form.Group widths='equal'>
                    <Form.Input 
                        label='Address' 
                        placeholder='Address'
                        // user 가 있을 떄만 user.name  
                        value={user && user.address} 
                        onChange = {(e) => this.onSetUserProp('address',e.target.value)} />
                </Form.Group>

                <Button primary onClick={() => onAddUser(user)}>Save</Button>
                <Button onClick={() => this.onClear()}>Clear</Button>
                {
                    selectedUser &&
                        <Button onClick={() => onUserDelete(selectedUser.idx)}>Delete</Button>
                }
                {
                    selectedUser &&
                        <Button onClick={() => onUserUpdate(selectedUser.idx,selectedUser)}>Update</Button>
                }
            </Form>            
        )
    }
}

export default NewForm;