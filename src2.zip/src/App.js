import React, { Component } from 'react';
import { Container,Grid,Segment } from 'semantic-ui-react';
import NewForm from './component/NewForm';
import UserList from './component/UserList';
import SearchBar from './component/SearchBar';

class App extends Component {

  constructor(props){
    super(props);
    this.state = {
      users : [],
      users_backup : [],
      selectedUser : null
    }
  }

  searchByName(name){

    let updateList = this.state.users_backup;

    // 이게 if 문?
    updateList = updateList.filter(user =>{
      return user.name.toLowerCase().search(name.toLowerCase()) !== -1;
    })

    this.setState({
      users: updateList
    })
  }

  idx = 0;
    getIdx = () => {
        return ++this.idx;
  }

  onAddUser(user){
    user.idx = this.getIdx();

    this.setState({
      users: [...this.state.users,user],
      users_backup: [...this.state.users_backup,user]
    })
  }

  onUserSelect(user){
    this.setState({
      selectedUser: user
    })
    console.log(this.state.selectedUser);
  }

  onUserDelete = (idx) => {
    const { users } = this.state;
    const index = users.findIndex(user => user.idx === idx);

    this.setState({
      users: [
        ...users.slice(0,index),
        ...users.slice(index+1,users.length)
      ]
    })
  }

  onUserUpdate = (idx, nowUser) => {
    const { users } = this.state;

    this.setState({
      users: users.map(
        user => idx === user.id
        ? {...user, ...nowUser}
        : user
      )
    })
  }

  render() {
    return (
      <div className="App">
        <Container style={{marginTop : 50}}>
          <Grid centered columns={2}>

            <Grid.Column>
              <Segment>
                <NewForm 
                  onAddUser = {this.onAddUser.bind(this)}
                  selectedUser = {this.state.selectedUser}
                  onUserDelete = {this.onUserDelete.bind(this)}
                  onUserUpdate = {this.onUserUpdate.bind(this)}
                />
              </Segment>
            </Grid.Column>

            <Grid.Column>
              <Segment>
                <SearchBar onSearchByName = {this.searchByName.bind(this)} />
              </Segment>
              <Segment>
                <UserList
                  users={this.state.users}
                  onUserSelect = {this.onUserSelect.bind(this)}
                  onUserDelete = {this.onUserDelete}
                  onUserUpdate = {this.onUserUpdate.bind(this)}
                ></UserList>
              </Segment>
            </Grid.Column>

          </Grid>
        </Container>
      </div>
    );
  }
}

export default App;
