import {combineReducers, createStore, applyMiddleware, compose} from 'redux';
import thunk from 'redux-thunk';

import userListReducer from './reducer/userListReducer';

const rootReducer = combineReducers({
  userListState : userListReducer,
})

// 브라우저 있는거 쓸지 리덕스꺼 쓸지 설정해준것 
// reducer 등록.
const composeEnhancers = compose;

// action과 store 사이에 middleware
const store = createStore(
  rootReducer,
  composeEnhancers(
    applyMiddleware(thunk)
  ) 
);

const {dispatch} = store;
export default store;
export {dispatch};