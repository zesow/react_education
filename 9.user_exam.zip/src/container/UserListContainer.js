import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Container, Button } from 'semantic-ui-react';
import UserTableView from '../view/UserTableView';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import LineButtons from '../shared/LineButtons';
import userListAction from '../action/userListAction';
import PageHeader from '../shared/PageHeader';

@autobind
class UserListContainer extends Component {

  componentDidMount(){
    this.findUserList();
  }

  findUserList(){
    this.props.userListAction.findUsers();
  }

  onClickReload(){
    this.findUserList();
  }

  onRouteUser(id){
    const { history } = this.props;
    history.push(`/users/${id}`);
  }

  render(){

    const { users } = this.props;

    return (
      <Container>
        <PageHeader text='사용자 목록' />

        <LineButtons>

          <Button onClick={this.onClickReload}>새로고침</Button>
        </LineButtons>

        <UserTableView 
          users={users}
          routeUserBasePath = '/users'
          onRouteUser = {this.onRouteUser}
        />
          
      </Container>
    )
  }
}

// 파라미터 이름이 뭐든지 상관없다. 리덕스에서 알아서 가져와준다.
const mapStateToProps = ({userListState}) => ({
  users : userListState.users,
})

const mapDispatchToProps = (dispatch) => ({
  userListAction: bindActionCreators(userListAction, dispatch),
})

export default connect(mapStateToProps, mapDispatchToProps)(UserListContainer);