import axios from 'axios';


// then == promise . 비동기 데이터 처리.
// 
function findUserList(){
  return axios.get('/user-api/users')
  .then((response) => response.data);
}

export default {
  findUserList,
}