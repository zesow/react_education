import Books from "../static_data/Books";

export default function(){
    return Books;
}