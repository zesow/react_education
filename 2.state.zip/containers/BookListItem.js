import React, {Component} from 'react';
import { Item,ItemMeta } from 'semantic-ui-react';

class BookListItem extends Component {
    
    render(){
        const { book, selectBook } = this.props;

        return(
            <Item onClick = {() => selectBook(book)}>
                <Item.Image size='tiny' src={book.imgUrl}/>
                <Item.Content>
                    <Item.Header>
                        {book.title}
                    </Item.Header>
                    <ItemMeta>{book.price}</ItemMeta>
                    <Item.Description>
                        {book.author}
                    </Item.Description>
                </Item.Content>
            </Item>
        );



        // 내가 한 version.
        // const {title,author,publisher,price,imgUrl,introduce} = this.props;

        // return(
        //     <Item onClick={() => this.props.onBookSelect()}>
        //         <Item.Image src={imgUrl}/>
        //         <Item.Content verticalAlign='middle'>
        //             <Item.Header>{title}</Item.Header>
        //             <ItemMeta>{author}</ItemMeta>
        //             <ItemMeta>{publisher}</ItemMeta>
        //             <ItemMeta>{price}</ItemMeta>
        //             <ItemMeta>{introduce}</ItemMeta>
        //         </Item.Content>
        //     </Item>
        // );
    }
}

export default BookListItem;