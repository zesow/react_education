import React, {
	Component
} from 'react';
import BookListItem from './BookListItem';
import {
	Item
} from 'semantic-ui-react';

import { bindActionCreators } from 'redux';
import {selectBook} from '../actions/index';
import { connect } from 'react-redux';

class BookList extends Component {

	renderList(){
		return this.props.books.map(book => {
			return (
				<BookListItem
					key={book.ISBN}
					book= {book}
					selectBook = {this.props.selectBook}
				/>
			)
		})
	}

	render(){
		return(
			<Item.Group divided link>
				{this.renderList()}
			</Item.Group>
		)
	}
}

function mapStateToProps(state){
	return {
		books: state.books
	}
}

// 뒤에는 action 의 selectbook.
// 
function mapDispatchToProps(dispatch){
	return bindActionCreators({selectBook : selectBook}, dispatch);
}

export default connect (mapStateToProps, mapDispatchToProps)(BookList);