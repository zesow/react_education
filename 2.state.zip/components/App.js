import React, { Component } from 'react';
import SearchBar from '../containers/SearchBar';
import {Segment,Grid, GridColumn} from 'semantic-ui-react';
import BookList from '../containers/BookList';
import Books from '../static_data/Books.js'
import BookDetail from '../containers/BookDetail';

class App extends Component {

  // 처음 초기화는 생성자 이용.
  constructor(props){
    super(props);
    this.state = {
      books: Books,
      selectedBook : Books[0] // 처음에 디테일 첫번째 책 나오도록.
    }


  }
  
  searchByTitle(title){
    // list 를 업데이트하는 타이틀.
    let updateList = Books;

    // 이게 if 문?
    updateList = updateList.filter(book=>{
      return book.title.toLowerCase().search(title.toLowerCase()) !== -1;
    })

    this.setState({
      books: updateList
    })
  }


  render() {
    // const books = Books;

    
    return (
      <div className="App">

      

      <Grid columns={2} stackable>

        <GridColumn>
          <Segment>
            <BookList />
          </Segment>
        </GridColumn>

        <GridColumn>
          <BookDetail />
        </GridColumn>

      </Grid>
      </div>
    );
  }
}

export default App;
