import React, { Component } from 'react';
import { Container,Grid,Segment } from 'semantic-ui-react';
import TodoListContainer from './container/TodoListContainer';
import TodoEditFormContainer from './container/TodoEditFormContainer';

class App extends Component {
  render() {
    return (
      <Container>
        <Grid centered columns = {2}>

          <Grid.Column>
            <Segment>
              <TodoEditFormContainer />
            </Segment>
          </Grid.Column>

          <Grid.Column>
            <Segment>
              <TodoListContainer />
            </Segment>
          </Grid.Column>

        </Grid>
      </Container>
    );
  }
}

export default App;
