// todo 들이 모여있음.

const actionType = {
  ADD_TODO : 'todoMap.addTodo'
}

const initialState = {
  todoMap : new Map()
}

// type이 문자열이 아니라 상수객체로. 늘어날 수 있으니까.
function reducer(state = initialState, {type,payload}){
  switch(type){
    case actionType.ADD_TODO :
      const todoMap = new Map(state.todoMap);
      todoMap.set(payload.id, payload);

      return {
        ...state,
        todoMap
      }
    default :
      return state;
  }
}

export default reducer;
export {actionType}