import {combineReducers, createStore, applyMiddleware, compose} from 'redux';
import thunk from 'redux-thunk';

import {todoReducer, todoMapReducer} from './reducer/index';

const rootReducer = combineReducers({
  todoState : todoReducer,
  todoMapState : todoMapReducer
})

// 브라우저 있는거 쓸지 리덕스꺼 쓸지 설정해준것 
// reducer 등록.
const composeEnhancers = compose;

// action과 store 사이에 middleware
const store = createStore(
  rootReducer,
  composeEnhancers(
    applyMiddleware(thunk)
  ) 
);

const {dispatch} = store;
export default store;
export {dispatch};