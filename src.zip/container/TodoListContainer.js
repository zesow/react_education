import React, { Component } from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import autobind from 'auto-bind';
import todoMapAction from '../action/TodoMapAction';
import TodoListView from '../view/TodoListView';

class TodoListContainer extends Component{
  constructor(props){
    super(props);
    autobind(this);
  }

  render(){
    // redux의 store에서 가져옴.
    const {todoMap} = this.props;

    let todos = Array.from(todoMap.values());
    return(
      <TodoListView 
        todos = {todos}
      />
    )
  }
}

const mapStateToProps = ({todoMapState}) => ({
  todoMap: todoMapState.todoMap
});

const mapDispatchToProps = (dispatch) => ({
  todoMapAction : bindActionCreators(todoMapAction, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(TodoListContainer);