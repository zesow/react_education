import React, { Component } from 'react';
import autobind from 'auto-bind';

import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import {generateId} from '../IDGenerator';
import todoAction from '../action/todoAction';
import todoMapAction from '../action/TodoMapAction';

import TodoEditFormView from '../view/TodoEditFormView';




class TodoEditFormContainer extends Component{
  constructor(props){
    super(props);
    autobind(this);
  }

  onSetTodoProp(name, value){
    this.props.todoAction.setTodoProp(name, value);
  }

  onAddTodo(){
    const { todo }= this.props;
    this.props.todoMapAction.addTodo({...todo,id: generateId(8)});
  }

  render(){
    const {todo} = this.props;
    return (
      <TodoEditFormView 
        todo = {todo}
        onSetTodoProp = {this.onSetTodoProp}
        onAddTodo = {this.onAddTodo}
      />
    )
  }
}

const mapStateToProps = ({todoState}) => ({
  todo: todoState.todo
})

const mapDispatchToProps = (dispatch) => ({
  todoAction: bindActionCreators(todoAction, dispatch),
  todoMapAction: bindActionCreators(todoMapAction, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(TodoEditFormContainer);